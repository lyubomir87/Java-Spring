package com.softuni.springdataautomapping.domains.entities;

public enum Role {
    ADMIN,
    USER
}
