package com.softuni.springintroex.controllers;

import com.softuni.springintroex.entities.Book;
import com.softuni.springintroex.services.AuthorService;
import com.softuni.springintroex.services.BookService;
import com.softuni.springintroex.services.CategoryService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class AppController implements CommandLineRunner {
    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final BookService bookService;

    public AppController(CategoryService categoryService, AuthorService authorService, BookService bookService) {
        this.categoryService = categoryService;
        this.authorService = authorService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... args) throws Exception {
        //seed
      //  categoryService.seedCategories();
       // authorService.seedAuthors();
       // bookService.seedBooks();

//ex.1
      //  List<Book>books=this.bookService.getAllBooksAfter2000();
      //  for (Book book : books) {
        //    System.out.println(book.getTitle());

      //  }


        //Ex.2

           // authorService.getBooksBefore1990().forEach(a -> {
             //   System.out.println(a.getFirstName() + " " + a.getLastName());
          //  });
        //Ex.3
        //this.authorService.findAllAuthorsByCountOfBooks()
               // .forEach(a->{
                  //  System.out.printf("%s %s %d\n",a.getFirstName(),a.getLastName(),a.getBooks().size());
             //   });


        //ex.4
        bookService.getAllBooksFromGeorgePowell().forEach(book -> {
            System.out.println(book.getTitle() + " " + book.getReleaseDate() + " " + book.getCopies());
        });
    }
}
