package com.softuni.jsonex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonExApplication {

    public static void main(String[] args) {
        SpringApplication.run(JsonExApplication.class, args);
    }

}
