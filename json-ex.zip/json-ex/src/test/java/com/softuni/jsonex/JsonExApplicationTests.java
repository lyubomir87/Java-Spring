package com.softuni.jsonex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonExApplicationTests {

    @Test
    void contextLoads() {
    }

}
